"""add indexes to productos for filter/sort performance

Revision ID: e5d8c2b0a7f1
Revises: c4a2f7b9d1e3
Create Date: 2026-06-17 00:00:00.000000

"""
from alembic import op


revision = 'e5d8c2b0a7f1'
down_revision = 'c4a2f7b9d1e3'
branch_labels = None
depends_on = None


def upgrade():
    op.create_index('ix_productos_activo', 'productos', ['activo'])
    op.create_index('ix_productos_precio', 'productos', ['precio'])
    op.create_index('ix_productos_vistas', 'productos', ['vistas'])
    op.create_index('ix_productos_fecha_creacion', 'productos', ['fecha_creacion'])
    op.create_index('ix_productos_valoracion_promedio', 'productos', ['valoracion_promedio'])
    op.create_index('ix_productos_nombre', 'productos', ['nombre'])


def downgrade():
    op.drop_index('ix_productos_nombre', table_name='productos')
    op.drop_index('ix_productos_valoracion_promedio', table_name='productos')
    op.drop_index('ix_productos_fecha_creacion', table_name='productos')
    op.drop_index('ix_productos_vistas', table_name='productos')
    op.drop_index('ix_productos_precio', table_name='productos')
    op.drop_index('ix_productos_activo', table_name='productos')
