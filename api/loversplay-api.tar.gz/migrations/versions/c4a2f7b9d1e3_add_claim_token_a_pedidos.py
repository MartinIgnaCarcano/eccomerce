"""add claim_token a pedidos

Revision ID: c4a2f7b9d1e3
Revises: b3f91d2a4c87
Create Date: 2026-05-28 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c4a2f7b9d1e3'
down_revision = 'b3f91d2a4c87'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('pedidos',
        sa.Column('claim_token', sa.String(length=64), nullable=True)
    )


def downgrade():
    op.drop_column('pedidos', 'claim_token')
