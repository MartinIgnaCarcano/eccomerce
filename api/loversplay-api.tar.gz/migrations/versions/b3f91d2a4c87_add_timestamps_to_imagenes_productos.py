"""add timestamps to imagenes_productos

Revision ID: b3f91d2a4c87
Revises: 8e8e27a01502
Create Date: 2026-05-02 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b3f91d2a4c87'
down_revision = '8e8e27a01502'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('imagenes_productos',
        sa.Column('fecha_creacion', sa.DateTime(), nullable=True)
    )
    op.add_column('imagenes_productos',
        sa.Column('fecha_modificacion', sa.DateTime(), nullable=True)
    )


def downgrade():
    op.drop_column('imagenes_productos', 'fecha_modificacion')
    op.drop_column('imagenes_productos', 'fecha_creacion')
